package com.yourapp.music.presentation.search

import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.util.UnstableApi
import com.yourapp.music.R
import com.yourapp.music.domain.model.Song
import com.yourapp.music.presentation.components.GenreTile
import com.yourapp.music.presentation.components.ShimmerSongRow
import com.yourapp.music.presentation.components.SongListItem
import com.yourapp.music.presentation.player.PlayerViewModel

@OptIn(UnstableApi::class)
@Composable
fun SearchScreen(
    onCancelClick: () -> Unit,
    onSongClick: (Song, List<Song>) -> Unit,
    viewModel: SearchViewModel = hiltViewModel(),
    playerViewModel: PlayerViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val playerState by playerViewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = state.query,
                onValueChange = viewModel::onQueryChange,
                placeholder = {
                    Text(stringResource(R.string.search_hint))
                },
                leadingIcon = {
                    Icon(
                        Icons.Filled.Search,
                        contentDescription = stringResource(
                            R.string.search
                        )
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    imeAction = ImeAction.Search
                ),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        viewModel.onSearchSubmit(state.query)
                    }
                ),
                shape = RoundedCornerShape(50),
                modifier = Modifier.weight(1f)
            )

            Spacer(Modifier.width(8.dp))

            TextButton(
                onClick = {
                    viewModel.onCancelSearch()
                    onCancelClick()
                }
            ) {
                Text(stringResource(R.string.cancel))
            }
        }

        Spacer(Modifier.height(16.dp))

        if (state.isSearchActive) {
            Text(
                text = when {
                    state.isLocalFallback -> stringResource(
                        R.string.local_results
                    )

                    state.isHybridSearch -> stringResource(R.string.hybrid_results)
                    else -> stringResource(R.string.suggested_songs)
                },
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(
                    start = 4.dp,
                    bottom = 8.dp
                )
            )

            when {
                state.isLoading && state.searchResults.isEmpty() -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(6) {
                            ShimmerSongRow()
                        }
                    }
                }

                state.searchResults.isEmpty() -> {
                    Text(
                        text = stringResource(R.string.no_search_results),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(12.dp)
                    )
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(
                            items = state.searchResults,
                            key = { it.id }
                        ) { song ->
                            SongListItem(
                                song = song,
                                onClick = {
                                    viewModel.saveRecentSearch(
                                        song.title
                                    )

                                    onSongClick(
                                        song,
                                        state.searchResults
                                    )
                                },
                                onPlayClick = {
                                    if (
                                        playerState.currentSong?.id == song.id
                                    ) {
                                        playerViewModel.togglePlayPause()
                                    } else {
                                        playerViewModel.playSong(
                                            song,
                                            state.searchResults
                                        )
                                    }
                                },
                                isCurrentSong =
                                    playerState.currentSong?.id == song.id,
                                isActivelyPlaying =
                                    playerState.currentSong?.id == song.id &&
                                            playerState.isPlaying
                            )
                        }
                        if (state.isLoading) {
                            items(3) {
                                ShimmerSongRow()
                            }
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        stringResource(R.string.recent_searches),
                        style = MaterialTheme.typography.titleLarge
                    )

                    TextButton(
                        onClick = viewModel::clearRecentSearches
                    ) {
                        Text(
                            stringResource(R.string.clear_all),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                state.recentSearches.forEach { recent ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.onSearchSubmit(
                                    recent.query
                                )
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.History,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(Modifier.width(12.dp))

                        Text(
                            recent.query,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(Modifier.height(24.dp))

                Text(
                    stringResource(R.string.browse_by_genre),
                    style = MaterialTheme.typography.titleLarge
                )

                Spacer(Modifier.height(12.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(
                        10.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(
                        10.dp
                    ),
                    modifier = Modifier.weight(
                        1f,
                        fill = false
                    )
                ) {
                    gridItems(
                        state.genres,
                        key = { it.id }
                    ) { genre ->
                        GenreTile(
                            genre = genre,
                            onClick = {
                                viewModel.onSearchSubmit(
                                    genre.name
                                )
                            }
                        )
                    }
                }
            }
        }

        state.errorMessage?.let { message ->
            Spacer(Modifier.height(8.dp))
            Text(
                message,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        Spacer(Modifier.height(16.dp))
    }
}
